#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

const double EPS = 0.1;

// original equation f(x) = 0
double f(double x)
{
    return -0.9 * pow(x, 2) + 1.7 * x + 2.5;
}

// g(x): rearranged so that x = g(x)
double g(double x)
{
    return sqrt(1.9 * x + 2.8);
}

// repeatedly substitutes xr into g(x) until error <= EPS
double fixedPoint(double xr)
{
    double xrold, error;
    int iter = 0;
    string err_display;

    do
    {
        xrold = xr;
        xr    = g(xr);                               // xi+1 = g(xi)
        error = abs((xr - xrold) / xr) * 100;

        if (iter == 0) err_display = "---";
        else           err_display = to_string(error);

        cout << "iteration: " << iter
             << " | xr: "     << fixed << setprecision(3) << xr
             << " | f(xr): "  << setprecision(3) << f(xr)
             << " | error%: " << err_display << endl;

        iter++;

    } while (err_display == "---" || error > EPS);

    return xr;
}

int main()
{
    double xr   = 0;
    double root = fixedPoint(xr);
    cout << "Root = " << fixed << setprecision(3) << root << endl;
    return 0;
}
