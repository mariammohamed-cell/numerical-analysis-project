#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

const double EPS = 0.1;

// the equation to find its root
double f(double x)
{
    return 2 * x - 1.75 * pow(x, 2) + 1.1 * pow(x, 3) - 0.25 * pow(x, 4);
}

// splits [xl, xu] in half each iteration until error <= EPS
double bisection(double xl, double xu)
{
    double xr, xrold, error;
    int iter = 0;
    string err_display;

    do
    {
        xrold = xr;
        xr    = (xl + xu) / 2;                      // midpoint
        error = abs((xr - xrold) / xr) * 100;

        if (iter == 0) err_display = "---";          // no error on first iteration
        else           err_display = to_string(error);

        cout << "iteration: " << iter
             << " | xl: "     << fixed << setprecision(3) << xl
             << " | f(xl): "  << setprecision(3) << f(xl)
             << " | xu: "     << setprecision(3) << xu
             << " | f(xu): "  << setprecision(3) << f(xu)
             << " | xr: "     << setprecision(3) << xr
             << " | f(xr): "  << setprecision(3) << f(xr)
             << " | error%: " << err_display << endl;

        // keep the side where sign changes
        if (f(xr) * f(xl) < 0)
            xu = xr;
        else
            xl = xr;

        iter++;

    } while (err_display == "---" || error > EPS);

    return xr;
}

int main()
{
    double xl = 0, xu = 1;
    double root = bisection(xl, xu);
    cout << "Root = " << fixed << setprecision(3) << root << endl;
    return 0;
}
