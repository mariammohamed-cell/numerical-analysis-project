#include <iostream>
#include <iomanip>
using namespace std;

// copies matrix _x into _y
void CopyMatrix(float _x[][4], float _y[][4])
{
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 4; j++)
            _y[i][j] = _x[i][j];
}

// same as Gauss Elimination but swaps rows to get the largest pivot first
void GaussEliminationPivoting(float _a[][4], float& m21, float& m31, float& m32,
                               float& x1,    float& x2,  float& x3)
{
    float a[3][4];
    CopyMatrix(_a, a);

    // --- Pivot for first column: bring largest value to top ---
    if (abs(a[1][0]) > abs(a[0][0]))
        for (int j = 0; j < 4; j++) swap(a[0][j], a[1][j]);

    if (abs(a[2][0]) > abs(a[0][0]))
        for (int j = 0; j < 4; j++) swap(a[0][j], a[2][j]);

    // --- Eliminate first column ---
    m21 = a[1][0] / a[0][0];
    a[1][0] -= m21 * a[0][0];
    a[1][1] -= m21 * a[0][1];
    a[1][2] -= m21 * a[0][2];
    a[1][3] -= m21 * a[0][3];

    m31 = a[2][0] / a[0][0];
    a[2][0] -= m31 * a[0][0];
    a[2][1] -= m31 * a[0][1];
    a[2][2] -= m31 * a[0][2];
    a[2][3] -= m31 * a[0][3];

    // --- Pivot for second column ---
    if (abs(a[2][1]) > abs(a[1][1]))
        for (int j = 0; j < 4; j++) swap(a[1][j], a[2][j]);

    // --- Eliminate second column ---
    m32 = a[2][1] / a[1][1];
    a[2][1] -= m32 * a[1][1];
    a[2][2] -= m32 * a[1][2];
    a[2][3] -= m32 * a[1][3];

    // --- Back substitution ---
    x3 =  a[2][3] / a[2][2];
    x2 = (a[1][3] -  a[1][2] * x3) / a[1][1];
    x1 = (a[0][3] - (a[0][2] * x3 + a[0][1] * x2)) / a[0][0];
}

int main()
{
    float a[3][4];
    float m21 = 0, m31 = 0, m32 = 0;
    float x1, x2, x3;

    cout << "Enter matrix:" << endl;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 4; j++)
        {
            cout << "Element [" << i << "][" << j << "]: ";
            cin  >> a[i][j];
        }

    GaussEliminationPivoting(a, m21, m31, m32, x1, x2, x3);

    cout << "x1 = " << fixed << setprecision(3) << x1 << endl;
    cout << "x2 = " << fixed << setprecision(3) << x2 << endl;
    cout << "x3 = " << fixed << setprecision(3) << x3 << endl;

    return 0;
}
