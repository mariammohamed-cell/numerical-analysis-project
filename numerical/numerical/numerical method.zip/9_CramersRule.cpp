#include <iostream>
#include <iomanip>
using namespace std;

// copies matrix _x into _y
void CopyMatrix(float _x[][4], float _y[][4])
{
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 4; j++)
            _y[i][j] = _x[i][j];
}

// computes determinant of a 3x3 matrix using cofactor expansion
float det3x3(float a[3][3])
{
    return a[0][0] * (a[1][1] * a[2][2] - a[1][2] * a[2][1])
         - a[0][1] * (a[1][0] * a[2][2] - a[1][2] * a[2][0])
         + a[0][2] * (a[1][0] * a[2][1] - a[1][1] * a[2][0]);
}

// xi = det(Ai) / det(A)  where Ai replaces column i with b
void CramersRule(float _a[][4], float& m21, float& m31, float& m32,
                 float& x1,     float& x2,  float& x3)
{
    float _ca[3][4];
    CopyMatrix(_a, _ca);

    // extract 3x3 coefficient matrix A
    float A[3][3];
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            A[i][j] = _a[i][j];

    // compute det(A)
    float detA = det3x3(A);
    cout << "Determinant of A = " << detA << endl;

    if (detA == 0)
    {
        cout << "System has no unique solution (detA = 0)." << endl;
        x1 = x2 = x3 = 0;
        return;
    }

    // extract b vector
    float b[3] = { _a[0][3], _a[1][3], _a[2][3] };
    float _detA[3];

    // for each variable: replace column i with b, compute determinant
    for (int i = 0; i < 3; i++)
    {
        float Ai[3][3];
        for (int r = 0; r < 3; r++)
            for (int c = 0; c < 3; c++)
                Ai[r][c] = (c == i) ? b[r] : A[r][c];

        _detA[i] = det3x3(Ai);
        cout << "A[" << (i + 1) << "] = " << _detA[i] << endl;
    }

    x1 = _detA[0] / detA;
    x2 = _detA[1] / detA;
    x3 = _detA[2] / detA;
}

int main()
{
    float a[3][4];
    float m21 = 0, m31 = 0, m32 = 0;
    float x1, x2, x3;

    cout << "Enter matrix:" << endl;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 4; j++)
        {
            cout << "Element [" << i << "][" << j << "]: ";
            cin  >> a[i][j];
        }

    CramersRule(a, m21, m31, m32, x1, x2, x3);

    cout << "x1 = " << fixed << setprecision(3) << x1 << endl;
    cout << "x2 = " << fixed << setprecision(3) << x2 << endl;
    cout << "x3 = " << fixed << setprecision(3) << x3 << endl;

    return 0;
}
