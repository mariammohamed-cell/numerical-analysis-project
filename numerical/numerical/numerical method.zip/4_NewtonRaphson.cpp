#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

const double EPS = 0.5;

// the equation to find its root
double f(double x)
{
    return 2 * x - 1.75 * pow(x, 2) + 1.1 * pow(x, 3) - 0.25 * pow(x, 4);
}

// derivative of f(x)
double f_dash(double x)
{
    return 2 - 3.5 * x + 3.3 * pow(x, 2) - pow(x, 3);
}

// xi+1 = xi - f(xi)/f'(xi)  — converges fast, needs derivative
double newtonRaphson(double xr)
{
    double xrold, error;
    int iter = 0;
    string err_display;

    do
    {
        xrold = xr;
        xr    = xr - (f(xr) / f_dash(xr));          // Newton-Raphson formula
        error = abs((xr - xrold) / xr) * 100;

        if (iter == 0) err_display = "---";
        else           err_display = to_string(error);

        cout << "iteration: " << iter
             << " | xr: "     << fixed << setprecision(3) << xr
             << " | f(xr): "  << setprecision(3) << f(xr)
             << " | f'(xr): " << setprecision(3) << f_dash(xr)
             << " | error%: " << err_display << endl;

        iter++;

    } while (err_display == "---" || error > EPS);

    return xr;
}

int main()
{
    double xr   = 1;
    double root = newtonRaphson(xr);
    cout << "Root = " << fixed << setprecision(3) << root << endl;
    return 0;
}
