#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

const double EPS = 0.5;

// the equation to find its root
double f(double x)
{
    return 2 * x - 1.75 * pow(x, 2) + 1.1 * pow(x, 3) - 0.25 * pow(x, 4);
}

// like Newton but approximates the derivative using two points (no need for f'(x))
double secant(double x_minis_1, double xi)
{
    double x_plus_1, error;
    int iter = 0;
    string err_display;

    do
    {
        // secant formula
        x_plus_1 = xi - (f(xi) * (x_minis_1 - xi)) / (f(x_minis_1) - f(xi));
        error     = abs((x_plus_1 - xi) / x_plus_1) * 100;

        if (iter == 0) err_display = "---";
        else           err_display = to_string(error);

        cout << "iteration: " << iter
             << " | xi-1: "   << fixed << setprecision(3) << x_minis_1
             << " | xi: "     << setprecision(3) << xi
             << " | xi+1: "   << setprecision(3) << x_plus_1
             << " | f(xi+1): "<< setprecision(3) << f(x_plus_1)
             << " | error%: " << err_display << endl;

        x_minis_1 = xi;          // shift: old xi becomes xi-1
        xi        = x_plus_1;    // new xi+1 becomes xi
        iter++;

    } while (err_display == "---" || error > EPS);

    return x_plus_1;
}

int main()
{
    double x_1 = 0, x0 = 0;
    double root = secant(x_1, x0);
    cout << "Root = " << fixed << setprecision(3) << root << endl;
    return 0;
}
